with open("G:/慕课网课程/AdvancePython/fb_object.txt", 'r', encoding='utf-16-be') as ins:
    for line in ins:
        print (line)
        break
