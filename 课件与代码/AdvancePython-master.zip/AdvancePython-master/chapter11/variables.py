
detail_url_list = []